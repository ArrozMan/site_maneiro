const db = require('../models/db');

// Adicionar um novo gasto
exports.addGasto = (req, res) => {
    const { usuario_id, categoria_id, valor, descricao } = req.body;
    const data_gasto = new Date().toISOString().slice(0, 10); // Data atual
    const sql = `INSERT INTO gastos (usuario_id, categoria_id, valor, descricao, data_gasto) 
                 VALUES (?, ?, ?, ?, ?)`;

    db.query(sql, [usuario_id, categoria_id, valor, descricao, data_gasto], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Erro ao adicionar o gasto');
            return;
        }
        res.status(201).send('Gasto adicionado com sucesso');
    });
};

// Obter todos os gastos
exports.getGastos = (req, res) => {
    const sql = `SELECT * FROM gastos`;

    db.query(sql, (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Erro ao obter os gastos');
            return;
        }
        res.status(200).json(result);
    });
};

// Atualizar um gasto
exports.updateGasto = (req, res) => {
    const { gasto_id } = req.params;
    const { valor, descricao } = req.body;
    const sql = `UPDATE gastos SET valor = ?, descricao = ? WHERE gasto_id = ?`;

    db.query(sql, [valor, descricao, gasto_id], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Erro ao atualizar o gasto');
            return;
        }
        res.send('Gasto atualizado com sucesso');
    });
};

// Deletar um gasto
exports.deleteGasto = (req, res) => {
    const { gasto_id } = req.params;
    const sql = `DELETE FROM gastos WHERE gasto_id = ?`;

    db.query(sql, [gasto_id], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Erro ao deletar o gasto');
            return;
        }
        res.send('Gasto deletado com sucesso');
    });
};
