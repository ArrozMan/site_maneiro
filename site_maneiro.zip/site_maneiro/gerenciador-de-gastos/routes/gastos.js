const express = require('express');
const router = express.Router();
const gastosController = require('../controllers/gastosController');

// Rota para adicionar um novo gasto
router.post('/gastos', gastosController.addGasto);

// Rota para obter todos os gastos
router.get('/gastos', gastosController.getGastos);

// Rota para atualizar um gasto
router.put('/gastos/:gasto_id', gastosController.updateGasto);

// Rota para deletar um gasto
router.delete('/gastos/:gasto_id', gastosController.deleteGasto);

module.exports = router;
