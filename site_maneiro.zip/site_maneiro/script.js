document.getElementById('gastoForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // Captura os valores do formulário
    const descricao = document.getElementById('descricao').value;
    const valor = document.getElementById('valor').value;
    const categoria = document.getElementById('categoria').value;
    const data = new Date().toLocaleDateString();

    // Insere os valores na tabela
    const table = document.getElementById('gastosBody');
    const newRow = table.insertRow();

    const cell1 = newRow.insertCell(0);
    const cell2 = newRow.insertCell(1);
    const cell3 = newRow.insertCell(2);
    const cell4 = newRow.insertCell(3);

    cell1.textContent = descricao;
    cell2.textContent = parseFloat(valor).toFixed(2); // Formata o valor com 2 casas decimais
    cell3.textContent = categoria;
    cell4.textContent = data;

    // Limpa os campos do formulário
    document.getElementById('gastoForm').reset();
});
